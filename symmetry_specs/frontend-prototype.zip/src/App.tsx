import { ArrowLeft, Clock, ImagePlus, PenLine, Home, Search, Newspaper, User, Bookmark } from 'lucide-react';
import React, { useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

// --- MOCK DATA ---
const INITIAL_ARTICLES = [
  {
    id: '1',
    title: 'Crisis Económica Global: Nuevas señales en los mercados',
    description: 'Análisis detallado de los factores macroeconómicos que están afectando a los mercados internacionales hoy.',
    date: '2024-03-23T12:00:00Z',
    imageUrl: 'https://images.unsplash.com/photo-1611974789855-9c2a0a223690?auto=format&fit=crop&w=600&q=80',
    tags: ['Tendencias', 'Economía'],
    verified: true,
    readTime: '4 min'
  },
  {
    id: '2',
    title: 'Tecnología 5G: El futuro real de la conectividad humana',
    description: 'La implementación de la red 5G está cambiando el juego para las industrias emergentes y vehículos autónomos.',
    date: '2024-03-23T11:45:00Z',
    imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=600&q=80',
    tags: ['Tecnología'],
    verified: true,
    readTime: '3 min'
  },
  {
    id: '3',
    title: 'Mercado Cripto en caída libre: ¿Qué dicen los expertos?',
    description: 'Bitcoin y las principales Altcoins sufren correcciones agresivas. Entiende por qué ocurrió esta caída repentina.',
    date: '2024-03-23T10:15:45Z',
    imageUrl: 'https://images.unsplash.com/photo-1516245834210-c4c142787335?auto=format&fit=crop&w=600&q=80',
    tags: ['Mercados'],
    verified: false,
    readTime: '5 min'
  }
];

// --- OWL ASSISTANT COMPONENT ---
const OwlAssistant = ({ text }: { text: string }) => (
  <motion.div
    initial={{ y: 50, opacity: 0 }}
    animate={{ y: 0, opacity: 1 }}
    transition={{ type: "spring", stiffness: 260, damping: 20 }}
    className="fixed bottom-20 right-4 bg-black border border-red-600 p-4 rounded-2xl shadow-[0_4px_20px_rgba(220,38,38,0.3)] max-w-[280px] z-40 flex gap-3 items-center"
  >
    <motion.div
      animate={{ y: [0, -5, 0] }}
      transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
      className="text-4xl filter drop-shadow-md"
    >
      🦉
    </motion.div>
    <div className="flex-1">
      <p className="text-xs text-red-500 font-bold mb-0.5">InfoVeraz IA</p>
      <p className="text-sm text-gray-200 leading-tight">{text}</p>
    </div>
  </motion.div>
);

export default function App() {
  const [currentView, setCurrentView] = useState<'home' | 'publish'>('home');
  const [articles, setArticles] = useState(INITIAL_ARTICLES);

  const formatDate = (isoString: string) => {
    const date = new Date(isoString);
    return new Intl.DateTimeFormat('es-ES', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(date);
  };

  const HomeScreen = () => (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="pb-24 pt-4"
    >
      <main className="max-w-3xl mx-auto px-4 space-y-6">
        {/* Banner CTA */}
        <section className="bg-gradient-to-r from-zinc-900 to-red-900/40 rounded-2xl p-5 flex items-center justify-between border border-red-900/30">
          <div>
            <h3 className="font-bold text-lg text-white mb-1"><span className="text-red-500">Explora</span> la verdad</h3>
            <p className="text-sm text-gray-300">Descubre noticias 100% verificadas por expertos.</p>
          </div>
          <div className="text-4xl animate-pulse">🕵️‍♂️</div>
        </section>

        {/* Section Title */}
        <div className="flex items-center justify-between px-2 pt-2">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            Últimas Noticias <span className="flex h-2 w-2 rounded-full bg-red-500"></span>
          </h2>
        </div>

        {/* News Feed */}
        <div className="flex flex-col gap-6">
          {articles.map((article, idx) => (
            <motion.article 
              key={article.id}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: idx * 0.1 }}
              whileHover={{ scale: 1.015 }}
              className="bg-zinc-900 rounded-2xl overflow-hidden shadow-xl border border-zinc-800 cursor-pointer flex flex-col sm:flex-row group"
            >
              <div className="relative w-full sm:w-[260px] h-48 sm:h-auto shrink-0 overflow-hidden">
                <img 
                  src={article.imageUrl} 
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 md:hidden opacity-80" />
              </div>
              
              <div className="p-5 flex-1 flex flex-col justify-center -mt-8 sm:mt-0 relative z-10">
                <div className="flex items-center gap-2 mb-3">
                  {article.verified ? (
                    <span className="bg-red-600 text-[10px] font-bold px-2.5 py-1 rounded-full text-white tracking-wide uppercase">
                      Verificado
                    </span>
                  ) : (
                    <span className="bg-zinc-700 text-[10px] font-bold px-2.5 py-1 rounded-full text-gray-300 tracking-wide uppercase">
                      En revisión
                    </span>
                  )}
                  <span className="text-gray-400 text-xs flex items-center gap-1 font-medium ml-auto">
                    <Clock size={12}/> {article.readTime || '3 min'}
                  </span>
                </div>
                
                <h2 className="text-xl sm:text-2xl font-bold leading-tight text-white mb-2 group-hover:text-red-400 transition-colors">
                  {article.title}
                </h2>
                
                <p className="text-gray-400 leading-relaxed text-sm line-clamp-2 mb-4">
                  {article.description}
                </p>

                <div className="mt-auto flex gap-2">
                  {article.tags?.map(tag => (
                    <span key={tag} className="text-xs font-semibold text-zinc-400 bg-zinc-800 px-2 py-0.5 rounded-md">
                      #{tag}
                    </span>
                  ))}
                  <span className="text-xs text-zinc-500 ml-auto mt-0.5">{formatDate(article.date)}</span>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </main>

      <OwlAssistant text="Las noticias aquí mostradas han pasado por filtros de cruce de fuentes. ¡Confía, pero verifica!" />
    </motion.div>
  );

  const PublishScreen = () => {
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [image, setImage] = useState<string | null>(null);

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => setImage(reader.result as string);
        reader.readAsDataURL(file);
      }
    };

    const handlePublish = () => {
      if (!title.trim()) return;

      const newArticle = {
        id: Math.random().toString(),
        title: title.trim(),
        description: content.trim() || 'Desarrollo de la noticia...',
        date: new Date().toISOString(),
        imageUrl: image || 'https://images.unsplash.com/photo-1546422904-90eab23c3d7e?auto=format&fit=crop&w=600&q=80',
        tags: ['Nueva Publicación'],
        verified: false,
        readTime: '1 min'
      };

      setArticles(prev => [newArticle, ...prev]);
      setCurrentView('home');
    };

    return (
      <motion.div 
        initial={{ opacity: 0, y: 20 }} 
        animate={{ opacity: 1, y: 0 }} 
        exit={{ opacity: 0 }}
        className="pb-24 pt-4 min-h-[calc(100vh-80px)]"
      >
        {/* Editor Content */}
        <main className="max-w-3xl mx-auto px-4">
          <div className="flex items-center justify-between mb-6">
            <button 
              onClick={() => setCurrentView('home')}
              className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors text-sm bg-zinc-900 border border-zinc-800 px-4 py-2 rounded-full"
            >
              <ArrowLeft size={16} />
              <span>Volver</span>
            </button>
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handlePublish}
              disabled={!title.trim()}
              className="font-bold text-sm text-white bg-red-600 disabled:bg-zinc-800 disabled:text-zinc-600 px-6 py-2 rounded-full transition-colors flex items-center gap-2 shadow-[0_0_10px_rgba(220,38,38,0.2)]"
            >
              <PenLine size={16} />
              Publicar Alerta
            </motion.button>
          </div>

          <div className="space-y-6">
            {/* Title Area */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 focus-within:border-red-500/50 transition-colors shadow-lg">
              <textarea 
                placeholder="Titular de impacto..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full text-2xl sm:text-4xl font-bold text-white placeholder:text-zinc-600 outline-none resize-none overflow-hidden bg-transparent pt-2"
                rows={2}
                style={{ minHeight: '80px' }}
              />
            </div>

            {/* Cover Image Area */}
            <div>
              <input 
                type="file" 
                accept="image/*" 
                className="hidden" 
                ref={fileInputRef}
                onChange={handleImageUpload}
              />
              {image ? (
                <div className="relative group rounded-2xl overflow-hidden cursor-pointer border border-zinc-800" onClick={() => fileInputRef.current?.click()}>
                  <img 
                    src={image} 
                    alt="Cover" 
                    className="w-full object-cover max-h-[300px]"
                  />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                    <span className="text-white font-bold flex items-center gap-2 bg-red-600 px-4 py-2 rounded-full">
                      <ImagePlus size={18} /> Cambiar Imagen
                    </span>
                  </div>
                </div>
              ) : (
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full p-10 bg-zinc-900 border-2 border-dashed border-zinc-700 hover:border-red-500/50 hover:bg-zinc-900/80 transition-all rounded-2xl flex flex-col items-center justify-center gap-4 text-zinc-500 group"
                >
                  <div className="w-14 h-14 rounded-full bg-zinc-800 text-red-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <ImagePlus size={28} />
                  </div>
                  <span className="font-medium text-sm">Adjuntar imagen de portada</span>
                </button>
              )}
            </div>

            {/* Body Content Area */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 focus-within:border-red-500/50 transition-colors shadow-lg">
              <textarea 
                placeholder="Desarrolla la noticia aquí. Mantén la objetividad..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full text-base sm:text-lg leading-relaxed text-gray-300 placeholder:text-zinc-600 outline-none resize-none bg-transparent min-h-[30vh]"
              />
            </div>
          </div>
        </main>
      </motion.div>
    );
  };

  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-red-500/30">
      
      {/* Global Brand Header */}
      <header className="bg-gradient-to-r from-black to-red-900/20 p-4 sticky top-0 z-50 border-b border-white/5 backdrop-blur-md">
        <div className="flex items-center justify-between max-w-3xl mx-auto">
          <div 
            className="flex items-center gap-3 cursor-pointer"
            onClick={() => setCurrentView('home')}
          >
            <motion.div 
              whileHover={{ rotate: 10 }}
              className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center text-xl shadow-[0_0_15px_rgba(220,38,38,0.4)] border border-red-500"
            >
              🦉
            </motion.div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Info<span className="text-red-500">Veraz</span></h1>
              <p className="text-[10px] text-gray-400 uppercase tracking-widest font-semibold mt-0.5">Información que importa</p>
            </div>
          </div>
          
          <button className="text-sm bg-zinc-800 hover:bg-zinc-700 text-white w-10 h-10 rounded-full flex items-center justify-center transition-colors">
            <Search size={18} />
          </button>
        </div>
      </header>

      <AnimatePresence mode="wait">
        {currentView === 'home' ? <HomeScreen key="home" /> : <PublishScreen key="publish" />}
      </AnimatePresence>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-black/95 backdrop-blur-lg border-t border-zinc-900 py-3 px-6 z-50">
        <div className="max-w-md mx-auto flex justify-between items-center text-xs font-medium">
          <button 
            onClick={() => setCurrentView('home')}
            className={`flex flex-col items-center gap-1.5 transition-colors ${currentView === 'home' ? 'text-red-500' : 'text-zinc-500 hover:text-zinc-300'}`}
          >
            <Home size={22} strokeWidth={currentView === 'home' ? 2.5 : 2} />
            <span>Inicio</span>
          </button>
          <button className="flex flex-col items-center gap-1.5 text-zinc-500 hover:text-zinc-300 transition-colors">
            <Newspaper size={22} />
            <span>Feed</span>
          </button>
          
          {/* FAB alternative in Bottom Nav */}
          <motion.button 
            whileTap={{ scale: 0.9 }}
            onClick={() => setCurrentView('publish')}
            className="flex flex-col items-center justify-center -mt-8 bg-red-600 text-white w-14 h-14 rounded-full shadow-[0_0_20px_rgba(220,38,38,0.4)] border-4 border-black"
          >
            <PenLine size={24} />
          </motion.button>

          <button className="flex flex-col items-center gap-1.5 text-zinc-500 hover:text-zinc-300 transition-colors">
            <Bookmark size={22} />
            <span>Guardadas</span>
          </button>
          <button className="flex flex-col items-center gap-1.5 text-zinc-500 hover:text-zinc-300 transition-colors">
            <User size={22} />
            <span>Perfil</span>
          </button>
        </div>
      </nav>
      
    </div>
  );
}
