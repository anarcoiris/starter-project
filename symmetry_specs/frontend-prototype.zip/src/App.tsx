import { ArrowLeft, Bookmark, ImagePlus, PenLine, Clock } from 'lucide-react';
import React, { useRef, useState } from 'react';

// --- MOCK DATA ---
const INITIAL_ARTICLES = [
  {
    id: '1',
    title: 'D.C.-area forecast: Heavy rain this morning, and winds turn gusty',
    description: 'The storm is in its peak across the region into midday, bringing significant precipitation and potential flooding to low-lying areas.',
    date: '2024-03-23T12:00:00Z',
    imageUrl: 'https://picsum.photos/seed/weather/600/400'
  },
  {
    id: '2',
    title: 'Truth Social made Trump richer and gave him a new megaphone.',
    description: 'Outside of Donald Trump\'s MAGA movement, his Truth Social platform remains a niche social network, but its financial impact is undeniable.',
    date: '2024-03-23T11:45:00Z',
    imageUrl: 'https://picsum.photos/seed/news2/600/400'
  },
  {
    id: '3',
    title: 'Moscow concert hall attack: Unpacking the geopolitical aftermath',
    description: 'More than 115 people have been killed and some 120 injured in one of the most devastating attacks in recent history.',
    date: '2024-03-23T10:15:45Z',
    imageUrl: 'https://picsum.photos/seed/city/600/400'
  }
];

export default function App() {
  const [currentView, setCurrentView] = useState<'home' | 'publish'>('home');
  const [articles, setArticles] = useState(INITIAL_ARTICLES);

  const formatDate = (isoString: string) => {
    const date = new Date(isoString);
    return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(date);
  };

  const HomeScreen = () => (
    <div className="animate-in fade-in duration-500">
      {/* Header */}
      <header className="sticky top-0 z-40 glass rounded-b-3xl mb-4">
        <div className="max-w-3xl mx-auto px-5 h-20 flex items-center justify-between">
          <div>
            <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold tracking-wider uppercase mb-1 inline-block">News Feed</span>
            <h1 className="font-bold text-2xl text-slate-900 leading-none">
              Chronicle<span className="text-blue-600">.</span>
            </h1>
          </div>
          <button 
            onClick={() => setCurrentView('publish')}
            className="flex items-center gap-2 text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 px-5 py-3 rounded-2xl transition-all active:scale-95 shadow-sm"
          >
            <PenLine size={18} />
            <span className="hidden sm:inline">Write Story</span>
            <span className="sm:hidden">Write</span>
          </button>
        </div>
      </header>

      {/* Feed Content */}
      <main className="max-w-3xl mx-auto px-5 pb-12 pt-2">
        <div className="flex flex-col gap-6">
          <p className="text-sm font-bold text-slate-800 uppercase tracking-wide px-2">Recent Stories</p>
          {articles.map((article, idx) => (
            <article key={article.id} className="m3-card group cursor-pointer hover:bg-white transition-colors">
              <div className="flex flex-col sm:flex-row gap-5 items-start p-2">
                {/* Image */}
                <div className="w-full sm:w-[220px] sm:order-2 shrink-0 overflow-hidden rounded-xl bg-slate-200">
                  <img 
                    src={article.imageUrl} 
                    alt={article.title}
                    className="w-full aspect-[3/2] sm:aspect-[4/3] object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                </div>
                
                {/* Text Content */}
                <div className="flex-1 sm:order-1 flex flex-col justify-center">
                  <div className="flex items-center gap-2 text-slate-500 mb-2 text-xs font-medium uppercase tracking-wider">
                    <Clock size={14} />
                    <span>{formatDate(article.date)}</span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold leading-tight text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">
                    {article.title}
                  </h2>
                  <p className="text-slate-600 leading-relaxed text-sm line-clamp-3">
                    {article.description}
                  </p>
                  
                  <div className="mt-4 flex items-center justify-between">
                    <span className="text-sm font-bold text-blue-600">
                      Read full story →
                    </span>
                    <button className="text-slate-400 hover:text-slate-800 transition-colors p-2 -mr-2 bg-slate-100 rounded-full hover:bg-slate-200">
                      <Bookmark size={18} strokeWidth={2} />
                    </button>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </main>
    </div>
  );

  const PublishScreen = () => {
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [image, setImage] = useState<string | null>(null);

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => setImage(reader.result as string);
        reader.readAsDataURL(file);
      }
    };

    const handlePublish = () => {
      if (!title.trim()) return;

      const newArticle = {
        id: Math.random().toString(),
        title: title.trim(),
        description: content.trim() || 'Breaking visual story.',
        date: new Date().toISOString(),
        imageUrl: image || 'https://picsum.photos/seed/breaking/600/400'
      };

      setArticles(prev => [newArticle, ...prev]);
      setCurrentView('home');
    };

    return (
      <div className="animate-in slide-in-from-bottom-4 duration-500">
        {/* Header */}
        <header className="sticky top-0 z-40 glass rounded-b-3xl">
          <div className="max-w-3xl mx-auto px-5 h-20 flex items-center justify-between">
            <button 
              onClick={() => setCurrentView('home')}
              className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors font-bold text-sm bg-slate-200/50 hover:bg-slate-200 px-4 py-2 rounded-xl"
            >
              <ArrowLeft size={18} />
              <span>Back</span>
            </button>
            <div className="flex gap-3">
              <button 
                onClick={handlePublish}
                disabled={!title.trim()}
                className="font-bold text-sm text-white bg-blue-600 disabled:bg-slate-300 disabled:text-slate-500 hover:bg-blue-700 px-6 py-2.5 rounded-xl transition-all shadow-sm"
              >
                Publish Story
              </button>
            </div>
          </div>
        </header>

        {/* Editor Content */}
        <main className="max-w-3xl mx-auto px-5 py-8">
          <div className="space-y-6">
            <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-semibold tracking-wider uppercase">New Draft</span>
            
            {/* Title Area */}
            <div className="m3-card !bg-white">
              <textarea 
                placeholder="Enter your headline..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full text-3xl sm:text-4xl font-bold text-slate-900 placeholder:text-slate-300 outline-none resize-none overflow-hidden bg-transparent pt-2"
                rows={2}
                style={{ minHeight: '80px' }}
              />
            </div>

            {/* Cover Image Area */}
            <div>
              <input 
                type="file" 
                accept="image/*" 
                className="hidden" 
                ref={fileInputRef}
                onChange={handleImageUpload}
              />
              {image ? (
                <div className="relative group rounded-[24px] overflow-hidden cursor-pointer shadow-sm border border-slate-200" onClick={() => fileInputRef.current?.click()}>
                  <img 
                    src={image} 
                    alt="Cover" 
                    className="w-full object-cover max-h-[400px]"
                  />
                  <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none backdrop-blur-sm">
                    <span className="text-white font-bold flex items-center gap-2 bg-slate-900/50 px-4 py-2 rounded-xl">
                      <ImagePlus size={20} /> Update Cover
                    </span>
                  </div>
                </div>
              ) : (
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full p-10 sm:p-14 m3-card border-2 border-dashed border-slate-300 hover:border-blue-400 hover:bg-blue-50/50 transition-all flex flex-col items-center justify-center gap-4 text-slate-500 group"
                >
                  <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <ImagePlus size={24} />
                  </div>
                  <span className="font-bold text-sm">Add Featured Cover Image</span>
                </button>
              )}
            </div>

            {/* Body Content Area */}
            <div className="m3-card !bg-white">
              <textarea 
                placeholder="Start writing your story..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full text-lg leading-relaxed text-slate-700 placeholder:text-slate-300 outline-none resize-none bg-transparent min-h-[35vh] p-2"
              />
            </div>
          </div>
        </main>
      </div>
    );
  };

  return (
    <div className="w-full min-h-screen">
      {currentView === 'home' ? <HomeScreen /> : <PublishScreen />}
    </div>
  );
}
